const db = require('./db/db');

db.query('SELECT 1', (err, results) => {
  if (err) {
    console.error('Database connection test failed:', err);
  } else {
    console.log('Database connection test successful:', results);
  }
  db.end(); // Close the connection
});