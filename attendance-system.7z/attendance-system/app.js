// app.js

const express = require('express');
const cors = require('cors'); 
const app = express();
const attendanceRoutes = require('./routes/attendance');

require('dotenv').config(); // Load environment variables

app.use(cors()); // Enable CORS
app.use(express.json()); // Parse incoming JSON
app.use('/api/attendance', attendanceRoutes); // Routes prefix

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});


console.log('Attendance routes loaded');

console.log('PUT /update route registered');
/* {
  "student_name": "Vraj Patel",
  "date": "2025-04-19",
  "time": "10:30:00",
  "status": "Present"
}*/